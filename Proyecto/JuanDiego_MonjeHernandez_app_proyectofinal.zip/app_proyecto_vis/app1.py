import dash # Iniciar el dashboard
from dash import dcc # Estilos
from dash import html # Página
# LIBRERÍAS PYTHON
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()
from plotly.subplots import make_subplots
import plotly.express as px # visualizaciones
import plotly.graph_objects as go # para mapas
from ipywidgets import widgets

#external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
#app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

#app = dash.Dash(__name__)

app = dash.Dash()

Abortos = pd.read_excel('Respuesta requerimiento IVE.xlsx', 
                 sheet_name = 'Mun_Prestador')

## LIMPIEZA

# Eliminando Información basura
Abortos.drop(range(3), inplace = True) 
Abortos.dropna(inplace=True)

# Renombrando Filas y Columnas
Abortos.rename(columns = Abortos.iloc[0], inplace = True)
Abortos.drop(3, inplace = True)
Abortos.rename(columns = {2009.0: 2009, 2010.0: 2010, 2011.0: 2011, 2012.0: 2012, 
                          2013.0: 2013, 2014.0: 2014, 2015.0: 2015, 2016.0: 2016, 
                          2017.0: 2017}, inplace=True)

# Dividiendo las columnas tipo string
Abortos[['Coddep', 'Dep']] = Abortos['Departamento'].str.split(' - ', 1, expand=True)
Abortos[['Codmun', 'Mun']] = Abortos['Municipio'].str.split(' - ', 1, expand=True)
Abortos[['Codpres', 'Pres']] = Abortos['Prestador'].str.split(' - ', 1, expand=True)
Abortos[['Coddiag', 'Diag']] = Abortos['Diagnósticos'].str.split(' - ', 1, expand=True)

# Reset index
Abortos.reset_index(inplace=True)

# Ordenando columnas de la tabla
Abortos = Abortos[['Coddep','Dep','Codmun','Mun','Codpres','Pres','Coddiag','Diag',
                  2009,2010,2011,2012,2013,2014,2015,2016,2017]]
Abortos = Abortos.astype({2009: int, 2010: int, 2011: int, 2012: int,2013: int, 
                2014: int, 2015: int, 2016: int, 2017.0: int})

# Seleccionando Columnas con las que se trabajará
Abortos = Abortos[['Coddep','Dep','Codmun','Mun','Coddiag','Diag',
                  2009,2010,2011,2012,2013,2014,2015,2016,2017]]

# Eliminando datos sin Minicipio ni Departamento establecido
Abortos = Abortos[(Abortos['Coddep'] != '-1') & (Abortos['Codmun'] != '-1')]

indexNames = Abortos[Abortos['Diag'].str.contains('OTRO ABORTO')].index
Abortos.drop(indexNames , inplace=True)

indexNames = Abortos[Abortos['Diag'].str.contains('RETENIDO')].index
Abortos.drop(indexNames , inplace=True)

## SE ELIMINAN LAS CATEGORÍAS: RETENIDO (al no tener subcategorías para clasificar) y 
#                              OTRO ABORTO (al ser la menor cantidad de abortos practicado)

Abortos[['Diag_1', 'Diag_x']] = Abortos['Diag'].str.split('ABORTO ', expand=True)[1].str.split(': ', expand=True)
Abortos[['Diag_2', 'Diag_3']] = Abortos['Diag_x'].str.split(', ', expand=True)
Abortos.Diag_3.replace({'COMPLICADO CON INFECCION GENITAL Y PELVIANA':'COMPLICADO CON INFECCIÓN GENITAL Y PELVIANA'},
                       inplace = True)

# drop
Abortos.drop(columns = 'Diag_x', inplace = True)

Abortos = Abortos[['Coddep','Dep','Codmun','Mun','Coddiag','Diag_1','Diag_2','Diag_3',
                  2009,2010,2011,2012,2013,2014,2015,2016,2017]]

### VISUALIZACIÓN 1

# Totales de Abortos Médicos por Departamento, ordenados
A_by_dep = Abortos.groupby(['Dep']).sum().sort_values([2017],ascending=False).head(10)
A_by_dep.reset_index(level=0, inplace = True)

figpie = make_subplots(rows=3, cols=3, specs=[[{"type": "pie"}, {"type": "pie"}, {"type": "pie"}],
                                              [{"type": "pie"}, {"type": "pie"}, {"type": "pie"}],
                                              [{"type": "pie"}, {"type": "pie"}, {"type": "pie"}]],
                      vertical_spacing=0.15)


figpie.add_trace(go.Pie(
     values=A_by_dep[2009],
     labels=A_by_dep['Dep'],
     domain=dict(x=[0.5, 1]),
     title='Abortos Totales 2009'),
     row=1, col=1)

figpie.add_trace(go.Pie(
     values=A_by_dep[2010],
     labels=A_by_dep['Dep'],
     domain=dict(x=[0, 0.5]),
     title='Abortos Totales 2010'), 
     row=1, col=2)

figpie.add_trace(go.Pie(
     values=A_by_dep[2011],
     labels=A_by_dep['Dep'],
     domain=dict(x=[0, 0.5]),
     title='Abortos Totales 2011'), 
     row=1, col=3)

figpie.add_trace(go.Pie(
     values=A_by_dep[2012],
     labels=A_by_dep['Dep'],
     domain=dict(x=[0, 0.5]),
     title='Abortos Totales 2012'), 
     row=2, col=1,)

figpie.add_trace(go.Pie(
     values=A_by_dep[2013],
     labels=A_by_dep['Dep'],
     domain=dict(x=[0, 0.5]),
     title='Abortos Totales 2013'), 
     row=2, col=2)

figpie.add_trace(go.Pie(
     values=A_by_dep[2014],
     labels=A_by_dep['Dep'],
     domain=dict(x=[0, 0.5]),
     title='Abortos Totales 2014'), 
     row=2, col=3)

figpie.add_trace(go.Pie(
     values=A_by_dep[2015],
     labels=A_by_dep['Dep'],
     domain=dict(x=[0, 0.5]),
     title='Abortos Totales 2015'), 
     row=3, col=1)

figpie.add_trace(go.Pie(
     values=A_by_dep[2016],
     labels=A_by_dep['Dep'],
     domain=dict(x=[0, 0.5]),
     title='Abortos Totales 2016'), 
     row=3, col=2)

figpie.add_trace(go.Pie(
     values=A_by_dep[2017],
     labels=A_by_dep['Dep'],
     domain=dict(x=[0, 0.5]),
     title='Abortos Totales 2017'), 
     row=3, col=3)

figpie.update_layout(
    font=dict(
        family="Arial, monospace",
        size=12,
        color="Black"))

figpie.update_layout(
    title={
        'text': "Abortos Totales por Año",
        'y':0.9,
        'x':0.5,
        'xanchor': 'center',
        'yanchor': 'top'}) 

### Visualización 2

Abortos_conAños = Abortos.melt(id_vars = ['Coddep','Dep','Codmun','Mun','Coddiag','Diag_1','Diag_2','Diag_3'],
                     value_vars=[2009,2010,2011,2012,2013,2014,2015,2016,2017],var_name= 'Año', value_name = 'Total_Abortos')
Abortos_conAños.head(10)

Abortos_conAños['Dep'].replace({' Antioquia' : 'ANTIOQUIA', ' Atlántico' : 'ATLÁNTICO',' Bogotá, D.C.' : 'BOGOTÁ, D. C.',
                                ' Bolívar' : 'BOLÍVAR', ' Boyacá' : 'BOYACÁ', ' Caldas' : 'CALDAS', ' Caquetá': 'CAQUETÁ',
                                ' Cauca' : 'CAUCA', ' Cesar' : 'CESAR', ' Córdoba' : 'CÓRDOBA',
                                ' Cundinamarca' : 'CUNDINAMARCA', ' Chocó' : 'CHOCÓ',' Huila' : 'HUILA',
                                ' La Guajira' : 'LA GUAJIRA', ' Magdalena' : 'MAGDALENA', ' Meta' : 'META',
                                ' Nariño' : 'NARIÑO', ' Norte de Santander' : 'NORTE DE SANTANDER',' Quindio' : 'QUINDÍO',
                                ' Risaralda' : 'RISARALDA', ' Santander' : 'SANTANDER',' Sucre' : 'SUCRE',
                                ' Tolima' : 'TOLIMA', ' Valle del Cauca' : 'VALLE DEL CAUCA', ' Arauca' : 'ARAUCA',
                                ' Casanare' : 'CASANARE', ' Putumayo' : 'PUTUMAYO',
                                ' Archipiélago de San Andrés, Providencia y Santa Catalina' : 'ARCHIPIÉLAGO DE SAN ANDRÉS, PROVIDENCIA Y',
                                ' Amazonas' : 'AMAZONAS', ' Guainía' : 'GUAINÍA', ' Guaviare' : 'GUAVIARE',
                                ' Vaupés' : 'VAUPÉS', ' Vichada' : 'VICHADA'},inplace=True)


ab = Abortos_conAños.groupby(['Coddep','Dep','Año'])[['Año','Total_Abortos']].sum()
ab.reset_index(inplace=True)
ab

# eliminando #-> No definido
ab = ab.drop(ab[ab['Dep'].isin(['1 - NO DEFINIDO'])].index.tolist())
# cambio de tipo de dato para el año
ab = ab.astype({'Año': object})
ab.head(10)

ab['Coddep'].replace({'05 ':'05', '08 ':'08', '11 ':'11', '13 ':'13', '15 ':'15', '17 ':'17', '18 ':'18', '19 ':'19',
                      '20 ':'20', '23 ':'23', '25 ':'25', '27 ':'27', '41 ':'41', '44 ':'44', '47 ':'47', '50 ':'50',
                      '52 ':'52', '54 ':'54', '63 ':'63', '66 ':'66', '68 ':'68', '70 ':'70', '73 ':'73', '76 ':'76',
                      '81 ':'81', '85 ':'85', '86 ':'86', '88 ':'88', '91 ':'91', '94 ':'94', '95 ':'95', '97 ':'97',
                      '99 ':'99'}, inplace=True)

# definiendo la base de coordenadas
df_depts = pd.read_csv("deptos_col.csv",
                       sep = ";", encoding="latin",  decimal=".", 
                       dtype={"id": str, 
                              "year": str})
df_depts.head(10)

df_depts.rename(columns={'id':'Coddep', 'name':'Dep', 'year' : 'Año'},inplace = True)

# base intermedia para la unión que se desea
qwe = pd.merge(df_depts[['Coddep','Dep','region','Año','lat','lon']], ab[['Coddep','Dep','Año']],
         how = 'left')
qwe.head(10)

qwe.replace({'Coddep': '5', 'Coddep': '8'}, 
    {'Coddep': '05', 'Coddep': '08'}, inplace=True)
qwe.replace({'Coddep': '5'}, 
    {'Coddep': '05'}, inplace=True)

df_Esp_Abortos = pd.merge(qwe[['Coddep','region','lat','lon']], ab[['Coddep','Dep','Año','Total_Abortos']],
                       on='Coddep')

df_Esp_Abortos.drop_duplicates(inplace=True)
df_Esp_Abortos.reset_index(inplace=True)
df_Esp_Abortos.drop('index', axis=1, inplace=True)
df_Esp_Abortos.head(20)

px.set_mapbox_access_token("pk.eyJ1IjoianVhbm1vbmplaCIsImEiOiJjbDFsMzc0MHEwNnVhM3B0OTd3NTVnNGw4In0.2SR_bwG_OYMfZ2G0D7OJUA")

figmap = px.scatter_mapbox(df_Esp_Abortos,
                        lat='lat',
                        lon='lon',
                        hover_name='Dep',
                        zoom=5,
                        color="region",
                        size="Total_Abortos",
                        animation_frame="Año", 
                        center = {"lat": 4.570868, "lon": -74.297333})
figmap.update_layout(
        title_text = 'Abortos Médicos por año en Colombia',
        showlegend = True,
        geo = dict(
            scope = 'south america',
            landcolor = 'rgb(217, 217, 217)',
        )
    )

# Visualización 3
available_Diag_1 = Abortos_conAños['Diag_1'].unique()
available_Diag_2 = Abortos_conAños['Diag_2'].unique()
    
## Visualización 4 
available_Año = Abortos_conAños['Año'].unique()

## Visualización 5
available_Dep = Abortos_conAños['Dep'].unique()

## Visualización 6
prueba = pd.merge(qwe[['Coddep','region']], Abortos_conAños[['Coddep','Dep','Diag_1','Diag_2','Año','Total_Abortos']],
                       on='Coddep')

##LAYOUT
app.layout = html.Div(
    children=[
        html.H1(children="ABORTOS EN COLOMBIA", # primer título
            style = { # style, forma del contenido
                        'textAlign': 'center',
            }),
        html.H2(children="Visualización Multivariada"), # título secundario
        html.P(
            children="En ésta visualización se pueden observar "
            "el número de abortos practicados " # contenido del párrafo
            "en Colombia, entre los años 2009-2017  "
            "desagregado por departamento."
            ),
            html.Div(dcc.Graph(  # estilo de esta división -> AGREGAR GRÁFICO
                id='vis-1', # no permite espacios
                figure=figpie, # llamar la visualización
                style={'height': 500, 'width': 1000}), # tamaño de la visualización
            ),
        html.H2(children="Mapa Abortos a nivel Nacional"), # título secundario
        html.P(
            children="En ésta visualización se puede observar " # contenido del párrafo
            "el número de abortos practicados " # contenido del párrafo
            "en Colombia, entre los años 2009-2017  "
            "desagregado por departamento ubicado en el mapa."
            ),
            html.Div(dcc.Graph(  # estilo de esta división -> AGREGAR GRÁFICO
                id='vis-2', # no permite espacios
                figure=figmap, # llamar la visualización
                style={'height': 500, 'width': 1000}), # tamaño de la visualización
            ),
            html.Div([
        html.H2(children='Gráfico Line Evolución Abortos'),#
        html.P(
            children="En ésta visualización se puede observar " # contenido del párrafo
            "la evolución del número de abortos practicados " # contenido del párrafo
            "en Colombia, entre los años 2009-2017  "
            "desagregado por tipo principal y secundario de aborto."
            ),
            html.Div(children='''
                
                Diagnóstico principal
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_diag_1',
                 options=[{'label': x, 'value': x} for x in available_Diag_1], # 2 widget
                value = 'ESPONTANEO',
                multi = False
                ),
            html.Div(children='''
                
                Diagnóstico Secundario
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_diag_2',
                 options=[{'label': x, 'value': x} for x in available_Diag_2], # 3er widget
                value = 'INCOMPLETO',
                multi = False
                ),
            dcc.Graph(
                id='vis-3'
            ),
     html.Div([
        html.Div([
            html.H2(children='Gráfico Evolución Abortos por Año y Diagnóstico Principal'),
            html.P(
            children="Este gráfico muestra el total de abortos sea de tipo "
                     "completo o con complicaciones, e incompleto, "
                     "desagregando por año y por diganóstico principal."
            ),
            html.Div(children='''
                
                Año
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_año',
                 options=[{'label': x, 'value': x} for x in available_Año], # 2 widget
                value = 2009,
                multi = False
                ),
            html.Div(children='''
                
                Diagnóstico Principal
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_diag_11',
                 options=[{'label': x, 'value': x} for x in available_Diag_1], # 3er widget
                value = 'ESPONTANEO',
                multi = False
                ),
            dcc.Graph(
                id='vis-4'
            ),
        ], className='six columns'),
        html.Div([
            html.H2(children='Gráfico Evolución Abortos por Año y Departamento'),
            html.P(
            children="Este gráfico muestra el total de abortos sea de tipo "
                     "completo o con complicaciones, e incompleto, "
                     "desagregando por año y por depa."
            ),#
            html.Div(children='''
                
                Año
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_año1',
                 options=[{'label': x, 'value': x} for x in available_Año], # 2 widget
                value = 2009,
                multi = False
                ),
            html.Div(children='''
                
                Diagnóstico Principal
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_dep',
                 options=[{'label': x, 'value': x} for x in available_Dep], # 3er widget
                value = 'Antioquia',
                multi = False
                ),
            dcc.Graph(
                id='vis-5'
            ),
        ], className='six columns'),
    ], className='row'),#
        html.H2(children="Treemap por Regiones y Departamentos"), # título secundario
        html.P(
            children="En ésta visualización se puede observar " # contenido del párrafo
            "el número de abortos practicados " # contenido del párrafo
            "en Colombia, entre los años 2009-2017  "
            "desagregado por región y departamento."
            ),
            html.Div(children='''
                
                Año
            
            '''),#
            dcc.Dropdown(
                id='crossfilter_año2',
                 options=[{'label': x, 'value': x} for x in available_Año], # 2 widget
                value = 2009,
                multi = False
                ),
            dcc.Graph(  # estilo de esta división -> AGREGAR GRÁFICO
                id='vis-6', # no permite espacios
                style={'height': 500, 'width': 1000}), # tamaño de la visualización  
        ]),

])  


## Viz 4
@app.callback(
    dash.dependencies.Output('vis-3', 'figure'),
    [dash.dependencies.Input('crossfilter_diag_1', 'value'),
     dash.dependencies.Input('crossfilter_diag_2', 'value')]
    )

def update_graph(tipo_diag_1_value, tipo_diag_2_value):
    query3 = Abortos_conAños[Abortos_conAños['Diag_1'] == tipo_diag_1_value]
    query3 = query3[query3['Diag_2'] == tipo_diag_2_value]
    
    fig3 = go.FigureWidget()

    fig3.add_trace(go.Scatter(x = query3['Año'].unique(),
                         y = query3.groupby('Año')['Total_Abortos'].sum(),
                         mode='lines+markers',
                         name='Total de Abortos'))
   

    fig3.update_layout({
                "margin": dict(l=20, r=20, t=20, b=20),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })

    return fig3

## Viz 5
@app.callback(
    dash.dependencies.Output('vis-4', 'figure'),
    [dash.dependencies.Input('crossfilter_año', 'value'),
     dash.dependencies.Input('crossfilter_diag_11', 'value')]
    )

def update_graph(tipo_año_value, tipo_diag_1_value):
    query4 = Abortos_conAños[Abortos_conAños['Año'] == tipo_año_value]
    query4 = query4[query4['Diag_1'] == tipo_diag_1_value]
    
    fig4 = go.FigureWidget(data=[go.Pie(labels=query4.Diag_2.unique(), 
                              values=query4.groupby('Diag_2').Total_Abortos.sum(),
                             title='Total de Abortos por Diganóstico Principal')])
   

    fig4.update_layout({
                "margin": dict(l=20, r=20, t=20, b=20),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })

    return fig4


## Viz
@app.callback(
    dash.dependencies.Output('vis-5', 'figure'),
    [dash.dependencies.Input('crossfilter_año1', 'value'),
     dash.dependencies.Input('crossfilter_dep', 'value')]
    )

def update_graph(tipo_año_value, tipo_dep_value):
    query5 = Abortos_conAños[Abortos_conAños['Año'] == tipo_año_value]
    query5 = query5[query5['Dep'] == tipo_dep_value]
    
    fig5 = go.FigureWidget(data=[go.Pie(labels=query5.Diag_2.unique(), 
                              values=query5.groupby('Diag_2').Total_Abortos.sum(),
                             title='Total de Abortos por Diganóstico Principal por Departamento')])
   

    fig5.update_layout({
                "margin": dict(l=20, r=20, t=20, b=20),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })

    return fig5

@app.callback(
    dash.dependencies.Output('vis-6', 'figure'),
    [dash.dependencies.Input('crossfilter_año2', 'value')]
    )

def update_graph(tipo_año_value):
    query6 = prueba[prueba['Año'] == tipo_año_value]

    fig6 = px.treemap(query6, path=['region', 'Dep'],
                 values='Total_Abortos'
                 )

    fig6.update_layout({
                "margin": dict(l=20, r=20, t=20, b=20),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })

    return fig6  

if __name__ == "__main__":
     app.run_server(debug=True)
